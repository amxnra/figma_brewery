$(document).ready(function() {
	//flexibility(document.documentElement);

  $(document).on('click', 'a[href="#"]', function(e){ e.preventDefault(); });

	$("body").on("click", ".js-menu-btn", function(e){
		e.preventDefault();
		$(this).parents('.menu').toggleClass('active');
		$(this).toggleClass('active');
		$('body').toggleClass('fixed');
	});


  // Age-gate
  $('.modal-age__btn--yes').on('click', function() {
    $(this).closest('.modal-age').fadeOut();
  });
  $('.modal-age__btn--no').on('click', function() {
    $(this).closest('.modal-age__cont').hide();
    $('.modal-age__fail').fadeIn();
  });


	var $gallery = $('.top-slider');
	var slideCount = $('.slideCount');
		$gallery.on('init reInit afterChange', function (event, slick, currentSlide, nextSlide) {
	    //currentSlide is undefined on init -- set it to 0 in this case (currentSlide is 0 based)
	    var i = (currentSlide ? currentSlide : 0) + 1;
	    $('.slideCount').html('<span class="slideCountItem">' + i + '</span> ' + '/' + ' <span class="slideCountAll">' + slick.slideCount + '</span>');
	  });
	
	$gallery.slick({
		swipe: true,
		swipeToSlide: true,
		touchThreshold: 10,
		prevArrow: $('.top-prev'),
		nextArrow: $('.top-next'),
		dots:false,
		//fade: true,
		useTransform:true,
		accessibility: false,
		infinite: false,
    });



    //PHOTO-SLIDER
    var $photo_gallery = $('.photo-slider');
	$photo_gallery.slick({
		swipe: true,
		swipeToSlide: true,
		touchThreshold: 10,
		prevArrow: $('.photo-slider-prev'),
		nextArrow: $('.photo-slider-next'),
		dots:false,
		//fade: true,
		useTransform:true,
		accessibility: false,
		infinite: false,
		slidesToShow: 3,
  		slidesToScroll: 1,
  		responsive: [
		    {
		      	breakpoint: 1024,
		      	settings: {
			        slidesToShow: 2,
  					slidesToScroll: 1,
		    	}
		    },
	    ]
    });


    $(".js-gallery").fancybox({
        speed : 330,
        transitionEffect: "slide", 
        animationEffect: "zoom-in-out", 
        //toolbar  : false,
        infobar: false,
        idleTime: false,
        buttons: [
            "close"
        ],
        image : {
            protect : true,
        }
    });


    //MAP
	ymaps.ready(initMap);



	//MENU
	$("body").on("click", ".js-menu__link", function(e){
		e.preventDefault();
	    var aid = $(this).attr("href");
	    $('html,body').animate({scrollTop: $(aid).offset().top},'slow');
		$('.menu__link').removeClass('active');
		$(this).addClass('active');
		
		
		var x = window.matchMedia("(max-width: 768px)")
		myFunction(x)
		x.addListener(myFunction)

		function myFunction(x) {
		  if (x.matches) {
		    $('body').removeClass('fixed');
		    $('.menu').removeClass('active');
		    $('.menu-btn').removeClass('active');
		  }
		}
	});


	//MONTH SHOW
	$("body").on("click", ".js-registration-month__more", function(e){
		e.preventDefault();
		$(this).hide();
		$('.registration-month-hidden').addClass('active');
	});


    var slickSetSelected = function() {
        var slideTrack = this.$slideTrack,
            currentSlide = this.currentSlide;

        slideTrack.find('.slick-selected').removeClass('slick-selected');
        slideTrack.find('[index="' + currentSlide + '"]').addClass('slick-selected');
    };


	//CALENDAR-SLIDER
    var $reg = $('.registration-days');
	$reg.slick({
		swipe: true,
		swipeToSlide: true,
		touchThreshold: 10,
		dots:false,
		//fade: true,
		useTransform:true,
		accessibility: false,
		infinite: false,
		slidesToShow: 16,
  		slidesToScroll: 1,
  		responsive: [
		    {
		      	breakpoint: 768,
		      	settings: {
			        slidesToShow: 10,
  					slidesToScroll: 1,
		    	}
		    },
		    {
		      	breakpoint: 600,
		      	settings: {
			        slidesToShow: 7,
  					slidesToScroll: 1,
		    	}
		    },
		    {
		      	breakpoint: 400,
		      	settings: {
			        slidesToShow: 6,
  					slidesToScroll: 1,
		    	}
		    }
	    ],
    });
    var todayDate = new Date();
    var mm = String(todayDate.getMonth() + 1).padStart(2, '0');
    var dd = $('.registration-days').data('day');
    var ddSlideIndex = dd - 1;
    var dayLength = $('.registration-days__item').length;

    if($(window).width() >= 768 && dd >= 17) {
        $('.registration-days').slick('slickGoTo', dayLength-16);
    } else if($(window).width() <= 767 && $(window).width() >= 600 && dd >= 22) {
        $('.registration-days').slick('slickGoTo', dayLength-10);
    } else if($(window).width() <= 599 && $(window).width() >= 400 && dd >= 25) {
        $('.registration-days').slick('slickGoTo', dayLength-7);
    } else if($(window).width() <= 399 && dd >= 27) {
        $('.registration-days').slick('slickGoTo', dayLength-5);
    } else $('.registration-days').slick('slickGoTo', ddSlideIndex);

    // input label
    $('.registration-form__item--double .input-wrap input').on('input change', function() {
      var _val = $(this).val();

      if (_val !== '') {
        $(this).parent().addClass('not-empty');
      } else {
        $(this).parent().removeClass('not-empty');
      }
    });

    $('#orderform-phone').mask('+000 (00) 000 00 00');


    //minus-plus
    $("body").on("click", ".count-minus", function(e){
        var $input = $(this).parent().find('.count-input');
        var count = parseInt($input.val()) - 1;
        count = count < 1 ? 1 : count;
        $input.val(count);
        $input.change();
        return false;
    });
 
    $("body").on("click", ".count-plus", function(e){
        var $input = $(this).parent().find('.count-input');
        $input.val(parseInt($input.val()) + 1);
        $input.change();
        return false;
    });



    if ($( ".js-input-date" ).length>0) {
    	var months = $('.input-wrap--calendar').data('months');
    	var nameDays = $('.input-wrap--calendar').data('days');
		$( ".js-input-date" ).datepicker({
			dateFormat : "dd.mm.yy",
			minDate: new Date($('#hiddendelivdate').val()),
			monthNames : months.split(','),
			dayNamesMin : nameDays.split(','),
		});
	}


	//SELECT-CUSTOM
	if ($('.fs').length>0) {
		//setTimeout(function() {
		 	$('.fs').styler();
		//}, 100)
	}
});

$(window).resize(function () {

});

document.addEventListener("scroll", function(){
	var top = document.getElementById('top');
	var st = window.pageYOffset || document.documentElement.scrollTop;
	if(st > 80) {
		top.classList.add('top-nav-fixed')
	} else {
		top.classList.remove('top-nav-fixed')
	}
}, false);

// functions
function initMap() {
	if ($('#map').length>0) {
		var icon = "front/img/content/label.png";

		var myMap = new ymaps.Map("map", {
	        center:[53.9153585,27.56159660000003],
	        zoom: 16,
	        controls: []
	    }); 
	            
	    var myPlacemark = new ymaps.Placemark([53.9153585,27.56159660000003],{
            balloonContentBody: '',
            },{
            iconLayout: 'default#image',
            iconImageHref: icon, 
            iconImageSize: [53, 98],
            iconImageOffset: [-27, -90]
    	});    

        myMap.geoObjects.add(myPlacemark);
     //    myMap.controls.add(
	    //     new ymaps.control.ZoomControl()
	    // );

	    var pixelCenter = myMap.getGlobalPixelCenter('map');
        pixelCenter1 = [
            pixelCenter[0] + 300,
            pixelCenter[1],
        ];
        var geoCenter1 = myMap.options.get('projection').fromGlobalPixels(pixelCenter1, myMap.getZoom());

        pixelCenter2 = [
            pixelCenter[0] + 100,
            pixelCenter[1],
        ];
        var geoCenter2 = myMap.options.get('projection').fromGlobalPixels(pixelCenter2, myMap.getZoom());

        pixelCenter3 = [
            pixelCenter[0] + 100,
            pixelCenter[1],
        ];
        var geoCenter3 = myMap.options.get('projection').fromGlobalPixels(pixelCenter3, myMap.getZoom());

        if($(window).width() > '1024'){
            myMap.setCenter(geoCenter1);
        }else if($(window).width() > '768'){
            myMap.setCenter(geoCenter2);
        }
        else if($(window).width() > '600'){
            myMap.setCenter(geoCenter3);
        }
        else{
            //myMap.setCenter(center);
            //map.behaviors.disable('drag');
        }

        myMap.controls.add(new ymaps.control.ZoomControl({options: {}}));
        myMap.behaviors.disable('scrollZoom')
    };
}