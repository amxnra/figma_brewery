var lending = new function () {
    var self = this;

    this.init = function () {
        $(document).ready(function () {
            $('#order-form').on('beforeSubmit', function (e) {
                if (self.validateCheckbox() && self.validateRecaptcha()) self.sendOrder();
                return false;
            });

            $(document).on('change', '#check1, #check2, #check3', function () {
                if ($(this).is(":checked")) {
                    $(this).siblings('.help-block-checkbox').addClass('hidden');
                } else {
                    $(this).siblings('.help-block-checkbox').removeClass('hidden');
                }
            });

            $(document).on('change', 'input[name=reCaptcha]', function () {
                if ($(this).val().length > 0) {
                    $('.help-block-recaptcha').addClass('hidden');
                } else {
                    $('.help-block-recaptcha').removeClass('hidden');
                }
            });

            $(document).on('click', '.control-js', function () {
                self.changeDays($(this).data('date'));
            });
            $(document).on('change', '.fs', function () {
                if ($(this).val().length > 0) {
                    self.changeDays($(this).val());
                }
            });

            $(document).on('click', '.registration-days__item', function () {
                $('#time-input').val($(this).data('value'));
            });
        });
    }

    this.changeDays = function ($date) {
        $.get( "/site/get-days", { date: $date } )
            .done(function( data ) {
                $('#wrap-days').html(data);
                self.initSlick();
            });
    }

    this.initSlick = function () {
        var $reg = $('.registration-days');
        $reg.slick({
            swipe: true,
            swipeToSlide: true,
            touchThreshold: 10,
            dots:false,
            //fade: true,
            useTransform:true,
            accessibility: false,
            infinite: false,
            slidesToShow: 16,
            slidesToScroll: 1,
            responsive: [
                {
                    breakpoint: 768,
                    settings: {
                        slidesToShow: 10,
                        slidesToScroll: 1,
                    }
                },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 7,
                        slidesToScroll: 1,
                    }
                },
                {
                    breakpoint: 400,
                    settings: {
                        slidesToShow: 6,
                        slidesToScroll: 1,
                    }
                }
            ],
        });
    }

    this.openPopup = function ($action) {
        $.fancybox.open({
            src  : $action,
            type: 'inline',
            speed : 330,
            transitionEffect: "slide",
            animationEffect: "zoom-in-out",
            //toolbar  : false,
            infobar: false,
            idleTime: false,
            closeExisting: true,
            buttons: [
                "close"
            ],
            image : {
                protect : true,
            },
        });
    }

    this.validateCheckbox = function () {
        if ($('#check1').is(':checked') && $('#check2').is(':checked')) {
            return true;
        } else {
            return false;
        }
    }

    this.validateCheckbox = function () {
        if ($('#check1').is(':checked') && $('#check3').is(':checked')) {
            return true;
        } else {
            return false;
        }
    }

    this.validateRecaptcha = function () {
        if ($('input[name=reCaptcha]').val().length > 0) {
            return true;
        } else {
            $('.help-block-recaptcha').removeClass('hidden');
            return false;
        }
    }

    this.sendOrder = function () {
        var elements = document.getElementById("order-form").elements;
        var $data ={};
        for(var i = 0 ; i < elements.length ; i++){
            var item = elements.item(i);
            $data[item.name] = item.value;
        }
        $data['OrderForm[time]'] = $('#time-input').val();
        $data['OrderForm[reCaptcha]'] = $('#g-recaptcha-response').val();
        $.ajax({
            url: 'site/order',
            type: 'post',
            data: $data,
            dataType: 'json'
        }).done(function(res) {
            if (res === 1) {
                self.openPopup('#thanks');
            } else {
                self.openPopup('#error');
            }
            grecaptcha.reset();
        });
    }

}
lending.init();
